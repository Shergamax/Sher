const express = require('express');
const session = require('express-session');
const flash = require('connect-flash');
const passport = require('./auth');
const { Client } = require('pg');
const path = require('path');
const morgan = require('morgan');

const app = express();
const port = 3000;

// Подключение к PostgreSQL
const client = new Client({
    user: 'postgres',
    host: 'localhost',
    database: 'car_dealership',
    password: '22081921',
    port: 5432,
});

client.connect()
    .then(() => console.log('Подключено к PostgreSQL'))
    .catch(err => console.error('Ошибка подключения к PostgreSQL:', err));

// Настройка Express
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: true, limit: '10kb' }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(morgan('dev'));

// Настройка сессии
app.use(session({
    secret: 'your-secret-key', // Замените на случайную строку
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false } // Убедитесь, что secure: false для HTTP, true для HTTPS
}));

// Подключение connect-flash
app.use(flash());

// Инициализация Passport
app.use(passport.initialize());
app.use(passport.session());

// Middleware для передачи данных в шаблоны
app.use((req, res, next) => {
    res.locals.user = req.user || null; // Передаем пользователя в шаблоны
    next();
});

// Middleware для проверки авторизации
const ensureAuthenticated = (req, res, next) => {
    if (req.isAuthenticated()) {
        return next(); // Пользователь авторизован, продолжаем
    }
    res.redirect('/login'); // Пользователь не авторизован, перенаправляем на страницу входа
};

// Middleware для проверки роли администратора
const isAdmin = (req, res, next) => {
    if (req.isAuthenticated() && req.user.role === 'admin') {
        return next();
    }
    res.status(403).send('Доступ запрещён');
};

// Универсальный обработчик ошибок для асинхронных функций
const asyncHandler = (fn) => (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(next);
};

// Маршруты для авторизации
app.get('/login', (req, res) => {
    const errorMessage = req.flash('error')[0]; // Получаем флэш-сообщение об ошибке
    res.render('login', { errorMessage }); // Передаём сообщение в шаблон
});

app.post('/login', (req, res, next) => {
    passport.authenticate('local', (err, user, info) => {
        if (err) {
            return next(err);
        }
        if (!user) {
            return res.status(401).json({ error: 'Неверный логин или пароль' });
        }

        req.login(user, (err) => {
            if (err) {
                return next(err);
            }
            return res.json({ success: true });
        });
    })(req, res, next);
});

app.get('/logout', (req, res) => {
    req.logout((err) => {
        if (err) {
            return next(err);
        }
        res.redirect('/login');
    });
});

// Применяем ensureAuthenticated ко всем маршрутам, кроме /login
app.use((req, res, next) => {
    if (req.path === '/login' || req.path.startsWith('/public')) {
        return next(); // Пропускаем проверку для страницы входа и статических файлов
    }
    ensureAuthenticated(req, res, next); // Проверяем авторизацию для остальных маршрутов
});

// Маршруты для страниц
app.get('/', (req, res) => {
    res.render('index'); // Рендерим шаблон index.ejs
});

app.get('/cars', ensureAuthenticated, asyncHandler(async (req, res) => {
    const result = await client.query('SELECT * FROM cars;');
    res.render('cars', { cars: result.rows }); // Передаем данные об автомобилях в шаблон
}));

app.get('/customers', ensureAuthenticated, asyncHandler(async (req, res) => {
    const result = await client.query('SELECT * FROM customers;');
    res.render('customers', { customers: result.rows }); // Передаем данные о клиентах в шаблон
}));

app.get('/employees', ensureAuthenticated, asyncHandler(async (req, res) => {
    const result = await client.query('SELECT * FROM employees;');
    res.render('employees', { employees: result.rows }); // Передаем данные о сотрудниках в шаблон
}));

app.get('/sales', ensureAuthenticated, asyncHandler(async (req, res) => {
    const result = await client.query('SELECT * FROM sales;');
    res.render('sales', { sales: result.rows }); // Передаем данные о продажах в шаблон
}));

app.get('/service', ensureAuthenticated, asyncHandler(async (req, res) => {
    const result = await client.query('SELECT * FROM service_records;');
    res.render('service', { serviceRecords: result.rows }); // Передаем данные о сервисных записях в шаблон
}));

app.get('/marketing', ensureAuthenticated, asyncHandler(async (req, res) => {
    const result = await client.query('SELECT * FROM marketing_campaigns;');
    res.render('marketing', { campaigns: result.rows }); // Передаем данные о маркетинговых акциях в шаблон
}));

// API для получения данных
app.get('/api/cars', ensureAuthenticated, asyncHandler(async (req, res) => {
    const result = await client.query('SELECT * FROM cars;');
    res.json(result.rows);
}));

app.get('/api/customers', ensureAuthenticated, asyncHandler(async (req, res) => {
    const result = await client.query('SELECT * FROM customers;');
    res.json(result.rows);
}));

app.get('/api/employees', ensureAuthenticated, asyncHandler(async (req, res) => {
    const result = await client.query('SELECT * FROM employees;');
    res.json(result.rows);
}));

app.get('/api/sales', ensureAuthenticated, asyncHandler(async (req, res) => {
    const result = await client.query('SELECT * FROM sales;');
    res.json(result.rows);
}));

app.get('/api/service', ensureAuthenticated, asyncHandler(async (req, res) => {
    const result = await client.query('SELECT * FROM service_records;');
    res.json(result.rows);
}));

app.get('/api/marketing', ensureAuthenticated, asyncHandler(async (req, res) => {
    const result = await client.query('SELECT * FROM marketing_campaigns;');
    res.json(result.rows);
}));

// API для добавления автомобиля
app.post('/api/cars', ensureAuthenticated, asyncHandler(async (req, res) => {
    const { brand, model, year, price, status } = req.body;

    // Добавляем автомобиль в базу данных
    const result = await client.query(
        'INSERT INTO cars (brand, model, year, price, status) VALUES ($1, $2, $3, $4, $5) RETURNING *',
        [brand, model, year, price, status]
    );

    // Отправляем ответ клиенту
    res.json({ success: true, car: result.rows[0] });
}));

// Защищённые маршруты для администратора
app.get('/admin', isAdmin, (req, res) => {
    res.send('Админская панель');
});

// Пример маршрута для редактирования данных (только для администратора)
app.post('/edit/:id', isAdmin, asyncHandler(async (req, res) => {
    const { id } = req.params;
    const { name, value } = req.body;
    await client.query('UPDATE some_table SET name = $1, value = $2 WHERE id = $3', [name, value, id]);
    res.send('Данные успешно обновлены');
}));

// Пример маршрута для удаления данных (только для администратора)
app.post('/delete/:id', isAdmin, asyncHandler(async (req, res) => {
    const { id } = req.params;
    await client.query('DELETE FROM some_table WHERE id = $1', [id]);
    res.send('Данные успешно удалены');
}));

// Обработка 404 (страница не найдена)
app.use((req, res) => {
    res.status(404).render('404'); // Создайте шаблон 404.ejs
});

// Обработка 500 (ошибка сервера)
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).render('500'); // Создайте шаблон 500.ejs
});

// Запуск сервера
app.listen(port, () => {
    console.log(`Сервер запущен на http://localhost:${port}`);
});