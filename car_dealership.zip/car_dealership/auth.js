const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const { Client } = require('pg');

const client = new Client({
    user: 'postgres',
    host: 'localhost',
    database: 'car_dealership',
    password: '22081921',
    port: 5432,
});

client.connect();

// Настройка стратегии аутентификации
passport.use(new LocalStrategy(
    async (username, password, done) => {
        try {
            // Ищем пользователя по имени
            const result = await client.query('SELECT * FROM users WHERE username = $1', [username]);
            if (result.rows.length === 0) {
                return done(null, false, { message: 'Неверное имя пользователя или пароль' });
            }

            const user = result.rows[0];

            // Сравниваем пароль в открытом виде
            if (password !== user.password) {
                return done(null, false, { message: 'Неверное имя пользователя или пароль' });
            }

            // Если пароль совпадает, возвращаем пользователя
            return done(null, user);
        } catch (err) {
            return done(err);
        }
    }
));

// Сериализация пользователя
passport.serializeUser((user, done) => {
    done(null, user.id);
});

// Десериализация пользователя
passport.deserializeUser(async (id, done) => {
    try {
        const result = await client.query('SELECT * FROM users WHERE id = $1', [id]);
        done(null, result.rows[0]);
    } catch (err) {
        done(err);
    }
});

module.exports = passport;