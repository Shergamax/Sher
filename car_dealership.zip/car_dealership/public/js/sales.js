document.addEventListener('DOMContentLoaded', () => {
    const salesTableBody = document.querySelector('#sales-table tbody');
    const addSaleForm = document.getElementById('add-sale-form');

    // Функция для загрузки данных о продажах
    const loadSales = async () => {
        try {
            const response = await fetch('/api/sales', {
                headers: {
                    'X-CSRF-Token': csrfToken,
                },
            });

            if (!response.ok) {
                throw new Error('Ошибка при загрузке данных');
            }

            const sales = await response.json();
            salesTableBody.innerHTML = '';

            sales.forEach(sale => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${sale.sale_date}</td>
                    <td>${sale.price}</td>
                    <td>${sale.payment_method}</td>
                    <td>${sale.car_id}</td>
                    <td>${sale.customer_id}</td>
                    <td>
                        <button onclick="editSale(${sale.id})">Редактировать</button>
                        <button onclick="deleteSale(${sale.id})">Удалить</button>
                    </td>
                `;
                salesTableBody.appendChild(row);
            });
        } catch (error) {
            console.error('Ошибка:', error);
            alert('Произошла ошибка при загрузке данных о продажах.');
        }
    };

    // Функция для добавления новой продажи
    const addSale = async (event) => {
        event.preventDefault();

        const sale_date = document.getElementById('sale_date').value;
        const price = document.getElementById('price').value;
        const payment_method = document.getElementById('payment_method').value;
        const car_id = document.getElementById('car_id').value;
        const customer_id = document.getElementById('customer_id').value;

        try {
            const response = await fetch('/api/sales', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': csrfToken,
                },
                body: JSON.stringify({ sale_date, price, payment_method, car_id, customer_id }),
            });

            if (!response.ok) {
                throw new Error('Ошибка при добавлении продажи');
            }

            const newSale = await response.json();
            console.log('Успешно:', newSale);

            addSaleForm.reset();
            await loadSales();
        } catch (error) {
            console.error('Ошибка:', error);
            alert('Произошла ошибка при добавлении продажи.');
        }
    };

    // Функция для редактирования продажи
    const editSale = async (id) => {
        const sale_date = prompt('Введите новую дату продажи:');
        const price = prompt('Введите новую цену:');
        const payment_method = prompt('Введите новый метод оплаты:');
        const car_id = prompt('Введите новый ID автомобиля:');
        const customer_id = prompt('Введите новый ID клиента:');

        if (sale_date && price && payment_method && car_id && customer_id) {
            try {
                const response = await fetch(`/api/sales/${id}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-Token': csrfToken,
                    },
                    body: JSON.stringify({ sale_date, price, payment_method, car_id, customer_id }),
                });

                if (!response.ok) {
                    throw new Error('Ошибка при редактировании продажи');
                }

                await loadSales();
            } catch (error) {
                console.error('Ошибка:', error);
                alert('Произошла ошибка при редактировании продажи.');
            }
        }
    };

    // Функция для удаления продажи
    const deleteSale = async (id) => {
        if (confirm('Вы уверены, что хотите удалить эту продажу?')) {
            try {
                const response = await fetch(`/api/sales/${id}`, {
                    method: 'DELETE',
                    headers: {
                        'X-CSRF-Token': csrfToken,
                    },
                });

                if (!response.ok) {
                    throw new Error('Ошибка при удалении продажи');
                }

                await loadSales();
            } catch (error) {
                console.error('Ошибка:', error);
                alert('Произошла ошибка при удалении продажи.');
            }
        }
    };

    // Загружаем данные о продажах при загрузке страницы
    loadSales();

    // Добавляем обработчик события для формы
    if (addSaleForm) {
        addSaleForm.addEventListener('submit', addSale);
    }
});