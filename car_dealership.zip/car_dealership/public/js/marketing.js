document.addEventListener('DOMContentLoaded', () => {
    const marketingTableBody = document.querySelector('#marketing-table tbody');
    const addMarketingForm = document.getElementById('add-marketing-form');

    // Функция для загрузки данных о маркетинговых акциях
    const loadMarketing = async () => {
        try {
            const response = await fetch('/api/marketing', {
                headers: {
                    'X-CSRF-Token': csrfToken,
                },
            });

            if (!response.ok) {
                throw new Error('Ошибка при загрузке данных');
            }

            const marketing = await response.json();
            marketingTableBody.innerHTML = '';

            marketing.forEach(campaign => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${campaign.name}</td>
                    <td>${campaign.description}</td>
                    <td>${campaign.start_date}</td>
                    <td>${campaign.end_date}</td>
                    <td>
                        <button onclick="editMarketing(${campaign.id})">Редактировать</button>
                        <button onclick="deleteMarketing(${campaign.id})">Удалить</button>
                    </td>
                `;
                marketingTableBody.appendChild(row);
            });
        } catch (error) {
            console.error('Ошибка:', error);
            alert('Произошла ошибка при загрузке данных о маркетинговых акциях.');
        }
    };

    // Функция для добавления новой маркетинговой акции
    const addMarketing = async (event) => {
        event.preventDefault();

        const name = document.getElementById('name').value;
        const description = document.getElementById('description').value;
        const start_date = document.getElementById('start_date').value;
        const end_date = document.getElementById('end_date').value;

        try {
            const response = await fetch('/api/marketing', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': csrfToken,
                },
                body: JSON.stringify({ name, description, start_date, end_date }),
            });

            if (!response.ok) {
                throw new Error('Ошибка при добавлении маркетинговой акции');
            }

            const newCampaign = await response.json();
            console.log('Успешно:', newCampaign);

            addMarketingForm.reset();
            await loadMarketing();
        } catch (error) {
            console.error('Ошибка:', error);
            alert('Произошла ошибка при добавлении маркетинговой акции.');
        }
    };

    // Функция для редактирования маркетинговой акции
    const editMarketing = async (id) => {
        const name = prompt('Введите новое название:');
        const description = prompt('Введите новое описание:');
        const start_date = prompt('Введите новую дату начала:');
        const end_date = prompt('Введите новую дату окончания:');

        if (name && description && start_date && end_date) {
            try {
                const response = await fetch(`/api/marketing/${id}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-Token': csrfToken,
                    },
                    body: JSON.stringify({ name, description, start_date, end_date }),
                });

                if (!response.ok) {
                    throw new Error('Ошибка при редактировании маркетинговой акции');
                }

                await loadMarketing();
            } catch (error) {
                console.error('Ошибка:', error);
                alert('Произошла ошибка при редактировании маркетинговой акции.');
            }
        }
    };

    // Функция для удаления маркетинговой акции
    const deleteMarketing = async (id) => {
        if (confirm('Вы уверены, что хотите удалить эту маркетинговую акцию?')) {
            try {
                const response = await fetch(`/api/marketing/${id}`, {
                    method: 'DELETE',
                    headers: {
                        'X-CSRF-Token': csrfToken,
                    },
                });

                if (!response.ok) {
                    throw new Error('Ошибка при удалении маркетинговой акции');
                }

                await loadMarketing();
            } catch (error) {
                console.error('Ошибка:', error);
                alert('Произошла ошибка при удалении маркетинговой акции.');
            }
        }
    };

    // Загружаем данные о маркетинговых акциях при загрузке страницы
    loadMarketing();

    // Добавляем обработчик события для формы
    if (addMarketingForm) {
        addMarketingForm.addEventListener('submit', addMarketing);
    }
});