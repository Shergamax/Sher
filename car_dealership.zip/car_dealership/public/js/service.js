document.addEventListener('DOMContentLoaded', () => {
    const serviceTableBody = document.querySelector('#service-table tbody');
    const addServiceForm = document.getElementById('add-service-form');

    // Функция для загрузки данных о сервисных записях
    const loadService = async () => {
        try {
            const response = await fetch('/api/service', {
                headers: {
                    'X-CSRF-Token': csrfToken,
                },
            });

            if (!response.ok) {
                throw new Error('Ошибка при загрузке данных');
            }

            const serviceRecords = await response.json();
            serviceTableBody.innerHTML = '';

            serviceRecords.forEach(record => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${record.service_date}</td>
                    <td>${record.service_type}</td>
                    <td>${record.description}</td>
                    <td>${record.cost}</td>
                    <td>${record.car_id}</td>
                    <td>
                        <button onclick="editService(${record.id})">Редактировать</button>
                        <button onclick="deleteService(${record.id})">Удалить</button>
                    </td>
                `;
                serviceTableBody.appendChild(row);
            });
        } catch (error) {
            console.error('Ошибка:', error);
            alert('Произошла ошибка при загрузке данных о сервисных записях.');
        }
    };

    // Функция для добавления новой сервисной записи
    const addService = async (event) => {
        event.preventDefault();

        const service_date = document.getElementById('service_date').value;
        const service_type = document.getElementById('service_type').value;
        const description = document.getElementById('description').value;
        const cost = document.getElementById('cost').value;
        const car_id = document.getElementById('car_id').value;

        try {
            const response = await fetch('/api/service', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': csrfToken,
                },
                body: JSON.stringify({ service_date, service_type, description, cost, car_id }),
            });

            if (!response.ok) {
                throw new Error('Ошибка при добавлении сервисной записи');
            }

            const newRecord = await response.json();
            console.log('Успешно:', newRecord);

            addServiceForm.reset();
            await loadService();
        } catch (error) {
            console.error('Ошибка:', error);
            alert('Произошла ошибка при добавлении сервисной записи.');
        }
    };

    // Функция для редактирования сервисной записи
    const editService = async (id) => {
        const service_date = prompt('Введите новую дату сервиса:');
        const service_type = prompt('Введите новый тип сервиса:');
        const description = prompt('Введите новое описание:');
        const cost = prompt('Введите новую стоимость:');
        const car_id = prompt('Введите новый ID автомобиля:');

        if (service_date && service_type && description && cost && car_id) {
            try {
                const response = await fetch(`/api/service/${id}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-Token': csrfToken,
                    },
                    body: JSON.stringify({ service_date, service_type, description, cost, car_id }),
                });

                if (!response.ok) {
                    throw new Error('Ошибка при редактировании сервисной записи');
                }

                await loadService();
            } catch (error) {
                console.error('Ошибка:', error);
                alert('Произошла ошибка при редактировании сервисной записи.');
            }
        }
    };

    // Функция для удаления сервисной записи
    const deleteService = async (id) => {
        if (confirm('Вы уверены, что хотите удалить эту сервисную запись?')) {
            try {
                const response = await fetch(`/api/service/${id}`, {
                    method: 'DELETE',
                    headers: {
                        'X-CSRF-Token': csrfToken,
                    },
                });

                if (!response.ok) {
                    throw new Error('Ошибка при удалении сервисной записи');
                }

                await loadService();
            } catch (error) {
                console.error('Ошибка:', error);
                alert('Произошла ошибка при удалении сервисной записи.');
            }
        }
    };

    // Загружаем данные о сервисных записях при загрузке страницы
    loadService();

    // Добавляем обработчик события для формы
    if (addServiceForm) {
        addServiceForm.addEventListener('submit', addService);
    }
});