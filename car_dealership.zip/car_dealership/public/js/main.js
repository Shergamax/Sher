document.addEventListener('DOMContentLoaded', () => {
    const carForm = document.getElementById('carForm');

    if (carForm) {
        carForm.addEventListener('submit', async (event) => {
            event.preventDefault(); // Отменяем стандартное поведение формы

            const model = document.getElementById('model').value;

            try {
                const response = await fetch('/api/cars', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-Token': csrfToken, // Передаем CSRF-токен в заголовке
                    },
                    body: JSON.stringify({ model }), // Отправляем данные в формате JSON
                });

                if (!response.ok) {
                    throw new Error('Ошибка при отправке данных');
                }

                const data = await response.json();
                console.log('Успешно:', data);
                alert('Автомобиль добавлен!');
            } catch (error) {
                console.error('Ошибка:', error);
                alert('Произошла ошибка при добавлении автомобиля.');
            }
        });
    }
});