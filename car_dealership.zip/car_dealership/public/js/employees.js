document.addEventListener('DOMContentLoaded', () => {
    const employeesTableBody = document.querySelector('#employees-table tbody');
    const addEmployeeForm = document.getElementById('add-employee-form');

    // Функция для загрузки данных о сотрудниках
    const loadEmployees = async () => {
        try {
            const response = await fetch('/api/employees', {
                headers: {
                    'X-CSRF-Token': csrfToken,
                },
            });

            if (!response.ok) {
                throw new Error('Ошибка при загрузке данных');
            }

            const employees = await response.json();
            employeesTableBody.innerHTML = '';

            employees.forEach(employee => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${employee.name}</td>
                    <td>${employee.position}</td>
                    <td>${employee.contact_info}</td>
                    <td>
                        <button onclick="editEmployee(${employee.id})">Редактировать</button>
                        <button onclick="deleteEmployee(${employee.id})">Удалить</button>
                    </td>
                `;
                employeesTableBody.appendChild(row);
            });
        } catch (error) {
            console.error('Ошибка:', error);
            alert('Произошла ошибка при загрузке данных о сотрудниках.');
        }
    };

    // Функция для добавления нового сотрудника
    const addEmployee = async (event) => {
        event.preventDefault();

        const name = document.getElementById('name').value;
        const position = document.getElementById('position').value;
        const contact_info = document.getElementById('contact_info').value;

        try {
            const response = await fetch('/api/employees', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': csrfToken,
                },
                body: JSON.stringify({ name, position, contact_info }),
            });

            if (!response.ok) {
                throw new Error('Ошибка при добавлении сотрудника');
            }

            const newEmployee = await response.json();
            console.log('Успешно:', newEmployee);

            addEmployeeForm.reset();
            await loadEmployees();
        } catch (error) {
            console.error('Ошибка:', error);
            alert('Произошла ошибка при добавлении сотрудника.');
        }
    };

    // Функция для редактирования сотрудника
    const editEmployee = async (id) => {
        const name = prompt('Введите новое имя:');
        const position = prompt('Введите новую должность:');
        const contact_info = prompt('Введите новые контактные данные:');

        if (name && position && contact_info) {
            try {
                const response = await fetch(`/api/employees/${id}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-Token': csrfToken,
                    },
                    body: JSON.stringify({ name, position, contact_info }),
                });

                if (!response.ok) {
                    throw new Error('Ошибка при редактировании сотрудника');
                }

                await loadEmployees();
            } catch (error) {
                console.error('Ошибка:', error);
                alert('Произошла ошибка при редактировании сотрудника.');
            }
        }
    };

    // Функция для удаления сотрудника
    const deleteEmployee = async (id) => {
        if (confirm('Вы уверены, что хотите удалить этого сотрудника?')) {
            try {
                const response = await fetch(`/api/employees/${id}`, {
                    method: 'DELETE',
                    headers: {
                        'X-CSRF-Token': csrfToken,
                    },
                });

                if (!response.ok) {
                    throw new Error('Ошибка при удалении сотрудника');
                }

                await loadEmployees();
            } catch (error) {
                console.error('Ошибка:', error);
                alert('Произошла ошибка при удалении сотрудника.');
            }
        }
    };

    // Загружаем данные о сотрудниках при загрузке страницы
    loadEmployees();

    // Добавляем обработчик события для формы
    if (addEmployeeForm) {
        addEmployeeForm.addEventListener('submit', addEmployee);
    }
});