document.addEventListener('DOMContentLoaded', () => {
    const customersTableBody = document.querySelector('#customers-table tbody');
    const addCustomerForm = document.getElementById('add-customer-form');

    // Функция для загрузки данных о клиентах
    const loadCustomers = async () => {
        try {
            const response = await fetch('/api/customers', {
                headers: {
                    'X-CSRF-Token': csrfToken,
                },
            });

            if (!response.ok) {
                throw new Error('Ошибка при загрузке данных');
            }

            const customers = await response.json();
            customersTableBody.innerHTML = '';

            customers.forEach(customer => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${customer.name}</td>
                    <td>${customer.phone}</td>
                    <td>${customer.email}</td>
                    <td>${customer.address}</td>
                    <td>
                        <button onclick="editCustomer(${customer.id})">Редактировать</button>
                        <button onclick="deleteCustomer(${customer.id})">Удалить</button>
                    </td>
                `;
                customersTableBody.appendChild(row);
            });
        } catch (error) {
            console.error('Ошибка:', error);
            alert('Произошла ошибка при загрузке данных о клиентах.');
        }
    };

    // Функция для добавления нового клиента
    const addCustomer = async (event) => {
        event.preventDefault();

        const name = document.getElementById('name').value;
        const phone = document.getElementById('phone').value;
        const email = document.getElementById('email').value;
        const address = document.getElementById('address').value;

        try {
            const response = await fetch('/api/customers', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': csrfToken,
                },
                body: JSON.stringify({ name, phone, email, address }),
            });

            if (!response.ok) {
                throw new Error('Ошибка при добавлении клиента');
            }

            const newCustomer = await response.json();
            console.log('Успешно:', newCustomer);

            addCustomerForm.reset();
            await loadCustomers();
        } catch (error) {
            console.error('Ошибка:', error);
            alert('Произошла ошибка при добавлении клиента.');
        }
    };

    // Функция для редактирования клиента
    const editCustomer = async (id) => {
        const name = prompt('Введите новое имя:');
        const phone = prompt('Введите новый телефон:');
        const email = prompt('Введите новый email:');
        const address = prompt('Введите новый адрес:');

        if (name && phone && email && address) {
            try {
                const response = await fetch(`/api/customers/${id}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-Token': csrfToken,
                    },
                    body: JSON.stringify({ name, phone, email, address }),
                });

                if (!response.ok) {
                    throw new Error('Ошибка при редактировании клиента');
                }

                await loadCustomers();
            } catch (error) {
                console.error('Ошибка:', error);
                alert('Произошла ошибка при редактировании клиента.');
            }
        }
    };

    // Функция для удаления клиента
    const deleteCustomer = async (id) => {
        if (confirm('Вы уверены, что хотите удалить этого клиента?')) {
            try {
                const response = await fetch(`/api/customers/${id}`, {
                    method: 'DELETE',
                    headers: {
                        'X-CSRF-Token': csrfToken,
                    },
                });

                if (!response.ok) {
                    throw new Error('Ошибка при удалении клиента');
                }

                await loadCustomers();
            } catch (error) {
                console.error('Ошибка:', error);
                alert('Произошла ошибка при удалении клиента.');
            }
        }
    };

    // Загружаем данные о клиентах при загрузке страницы
    loadCustomers();

    // Добавляем обработчик события для формы
    if (addCustomerForm) {
        addCustomerForm.addEventListener('submit', addCustomer);
    }
});