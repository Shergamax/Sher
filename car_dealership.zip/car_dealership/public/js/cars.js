document.addEventListener('DOMContentLoaded', () => {
    const carsTableBody = document.querySelector('#cars-table tbody');
    const addCarForm = document.getElementById('add-car-form');

    // Функция для загрузки данных об автомобилях
    const loadCars = async () => {
        try {
            const response = await fetch('/api/cars');

            if (!response.ok) {
                throw new Error('Ошибка при загрузке данных');
            }

            const cars = await response.json();
            carsTableBody.innerHTML = '';

            cars.forEach(car => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${car.brand}</td>
                    <td>${car.model}</td>
                    <td>${car.year}</td>
                    <td>${car.price}</td>
                    <td>${car.status}</td>
                    <td>
                        <button onclick="editCar(${car.id})">Редактировать</button>
                        <button onclick="deleteCar(${car.id})">Удалить</button>
                    </td>
                `;
                carsTableBody.appendChild(row);
            });
        } catch (error) {
            console.error('Ошибка:', error);
            alert('Произошла ошибка при загрузке данных об автомобилях.');
        }
    };

    // Функция для добавления нового автомобиля
    const addCar = async (event) => {
        event.preventDefault();

        const brand = document.getElementById('brand').value;
        const model = document.getElementById('model').value;
        const year = document.getElementById('year').value;
        const price = document.getElementById('price').value;
        const status = document.getElementById('status').value;

        try {
            const response = await fetch('/api/cars', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ brand, model, year, price, status }),
            });

            if (!response.ok) {
                throw new Error('Ошибка при добавлении автомобиля');
            }

            const newCar = await response.json();
            console.log('Успешно:', newCar);

            addCarForm.reset();
            await loadCars();
        } catch (error) {
            console.error('Ошибка:', error);
            alert('Произошла ошибка при добавлении автомобиля.');
        }
    };

    // Функция для редактирования автомобиля
    const editCar = async (id) => {
        const brand = prompt('Введите новый бренд:');
        const model = prompt('Введите новую модель:');
        const year = prompt('Введите новый год выпуска:');
        const price = prompt('Введите новую цену:');
        const status = prompt('Введите новый статус:');

        if (brand && model && year && price && status) {
            try {
                const response = await fetch(`/api/cars/${id}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ brand, model, year, price, status }),
                });

                if (!response.ok) {
                    throw new Error('Ошибка при редактировании автомобиля');
                }

                await loadCars();
            } catch (error) {
                console.error('Ошибка:', error);
                alert('Произошла ошибка при редактировании автомобиля.');
            }
        }
    };

    // Функция для удаления автомобиля
    const deleteCar = async (id) => {
        if (confirm('Вы уверены, что хотите удалить этот автомобиль?')) {
            try {
                const response = await fetch(`/api/cars/${id}`, {
                    method: 'DELETE',
                });

                if (!response.ok) {
                    throw new Error('Ошибка при удалении автомобиля');
                }

                await loadCars();
            } catch (error) {
                console.error('Ошибка:', error);
                alert('Произошла ошибка при удалении автомобиля.');
            }
        }
    };

    // Загружаем данные об автомобилях при загрузке страницы
    loadCars();

    // Добавляем обработчик события для формы
    if (addCarForm) {
        addCarForm.addEventListener('submit', addCar);
    }
});