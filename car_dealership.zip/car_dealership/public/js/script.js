document.addEventListener('DOMContentLoaded', () => {
    // Загрузка данных об автомобилях
    fetch('/api/cars')
        .then(response => response.json())
        .then(data => {
            const carsTable = document.querySelector('#cars-table tbody');
            data.forEach(car => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${car.brand}</td>
                    <td>${car.model}</td>
                    <td>${car.year}</td>
                    <td>${car.price}</td>
                    <td>${car.status}</td>
                `;
                carsTable.appendChild(row);
            });
        });

    // Загрузка данных о клиентах
    fetch('/api/customers')
        .then(response => response.json())
        .then(data => {
            const customersTable = document.querySelector('#customers-table tbody');
            data.forEach(customer => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${customer.full_name}</td>
                    <td>${customer.phone}</td>
                    <td>${customer.email}</td>
                `;
                customersTable.appendChild(row);
            });
        });
});